#! /usr/bin/env python
# -*- coding: utf-8 -*-
"""
Created on Mon Mar 24 22:22:44 2014
@author: henrikdreyer
"""
import numpy as np
#import scipy
import pfaffian as pf

def add_vertex(atX,atY,number):
    global f
    f.write("!{(")
    f.write(str(atX))
    f.write(",")
    f.write(str(atY))
    f.write(") }*+{\\bullet_{"+ str(number)+ "}}=\"" + str(number) +"\"\n")

def add_edge(from_vertex,to_vertex,value,over_or_under=1):
    global f
    if over_or_under==1:
        f.write("\"")
        f.write(str(int(from_vertex)))
        f.write("\"-\"")
        f.write(str(int(to_vertex)))
        f.write("\" ^{")
        f.write(str(value))
        f.write("}")
        f.write("\n")
    else:
        f.write("\"")
        f.write(str(int(from_vertex)))
        f.write("\"-\"")
        f.write(str(int(to_vertex)))
        f.write("\" _{")
        f.write(str(value))
        f.write("}")
        f.write("\n")



def add_one_qubit_gate(acts_on,a,b,c,d,final_gate):
    global p,q,A,T,g,k,X,Y
    A[q[acts_on],k+1] = 1 #fill upper diagonal
    add_vertex(X+1,n-1-acts_on,k+1)
    add_edge(q[acts_on],k+1,1,1)
    X=X+1
    Y=n-1-acts_on
    T=np.append(T,[k+2])
    A[k+1,k+2] = a*np.conjugate(c)/abs(c)**2 #assume c neq 0 for now
    A[k+1,k+3] = b
    A[k+2,k+3] = d
    A[k+3,k+4] = c
    add_vertex(X+0.5,n-1-acts_on+0.5,k+2)    
    add_vertex(X+0.5,n-1-acts_on-0.5,k+3)
    add_vertex(X+1.0,n-1-acts_on,k+4)
    add_edge(k+1,k+2,a/c,1)
    add_edge(k+1,k+3,b,0)
    add_edge(k+2,k+3,d,1)
    add_edge(k+3,k+4,c,0)
    k=k+4
    X=X+2
    q[acts_on] = k
    for i in range(0,n):
        p[i] = q[i]
        q[i] = k+i+1
        A[p[i],q[i]]=1
        add_vertex(X+dist*i,n-1-i,k+i+1)
        add_edge(p[i],q[i],1,1)
    k=k+n
    X=X+dist*(n-1)+1
    if final_gate==0:
        for i in range(n-1,-1,-1):
            p[i] = q[i]
            q[i] = k+1+n-1-i
            add_vertex(X+dist*(n-1-i),n-1-i,k+1+n-1-i)
            add_edge(p[i],q[i],1,1)
            A[p[i],q[i]] = 1
        k=k+1+n-1
        X=X+dist*(n-1)
        
def add_two_qubit_gate(acts_on,a,b,c,d,e,f,g,h,final_gate):
    global p,q,A,T,k,X,Y
    A[q[acts_on],k+1] = 1 #fill upper diagonal
    A[q[acts_on+1],k+2] = 1
    add_vertex(X+1,n-1-acts_on,k+1)
    add_vertex(X+1+dist,n-1-(acts_on+1),k+2)
    add_edge(q[acts_on],k+1,1,1)
    add_edge(q[acts_on+1],k+2,1,1)
    X=X+1+dist
    #Y=n-1-acts_on
    #T=np.append(T,[k+2])
    t = np.conjugate(d)/abs(d)**2
    A[k+1,k+2] = t*b #assume c neq 0 for now
    A[k+1,k+5] = -t*g
    A[k+1,k+6] = t*h
    A[k+2,k+5] = t*e
    A[k+2,k+6] = -t*f
    A[k+3,k+4] = d
    A[k+5,k+6] = t*c
    
    add_vertex(X+0.5,n-1-acts_on+0.5,k+3)    
    add_vertex(X+0.5,n-1-(acts_on+1)-0.5,k+4)
    add_vertex(X+1.0,n-1-(acts_on+1),k+5)
    add_vertex(X+1.0+dist,n-1-acts_on,k+6)
    
    add_edge(k+1,k+2,t*b,1)
    add_edge(k+1,k+5,-t*g,0)
    add_edge(k+1,k+6,t*h,0)
    add_edge(k+2,k+5,t*e,0)
    add_edge(k+2,k+6,-t*f,0)
    add_edge(k+3,k+4,1./t,0)
    add_edge(k+5,k+6,t*c,0)
    
    k=k+6
    X=X+2+dist
    q[acts_on] = k
    q[acts_on+1] = k-1
    for i in range(0,n):
        p[i] = q[i]
        q[i] = k+i+1
        A[p[i],q[i]]=1
        add_vertex(X+dist*i,n-1-i,k+i+1)
        add_edge(p[i],q[i],1,1)
    k=k+n
    X=X+dist*(n-1)+1
    if final_gate==0:
        for i in range(n-1,-1,-1):
            p[i] = q[i]
            q[i] = k+1+n-1-i
            add_vertex(X+dist*(n-1-i),n-1-i,k+1+n-1-i)
            add_edge(p[i],q[i],1,1)
            A[p[i],q[i]] = 1
        k=k+1+n-1
        X=X+dist*(n-1)

def compute_pfaffian_sum(B,T):
    #IF B is even
    sizeB=np.shape(B)[0]
    if sizeB % 2 == 0:
        Lambda=np.zeros((sizeB,sizeB))
        l=np.zeros(sizeB)
        for i in T:
            l[i]=1
        for i in range(sizeB):
            for j in range(sizeB):
                if i<j:
                    Lambda[i,j]=(-1)**(j-i+1)*l[i]*l[j]
                elif i>j:
                    Lambda[i,j]=(-1)**(i-j)*l[i]*l[j]
        return pf.pfaffian(B+Lambda)
    elif sizeB % 2 != 0:
        temp = np.vstack((B,np.zeros(sizeB)))
        B_plus = np.column_stack((temp,np.zeros(sizeB+1)))
        Lambda_plus = np.zeros((sizeB+1,sizeB+1))
        l=np.zeros(sizeB+1)
        l[sizeB]=1
        for i in T:
            l[i]=1
        for i in range(sizeB+1):
            for j in range(sizeB+1):
                if i<j:
                    Lambda_plus[i,j]=(-1)**(j-i+1)*l[i]*l[j]
                elif i>j:
                    Lambda_plus[i,j]=(-1)**(i-j)*l[i]*l[j]
        return pf.pfaffian(B_plus+Lambda_plus)

def output(A,input_state, output_state, omittables):
    B=A
    f.write("The probability to obtain $\\ket{")
    for i in range(n):
        f.write(str(output_state[i]))
    f.write("}$ from $\\ket{")
    for i in range(n):
        f.write(str(input_state[i]))
    f.write("}$ is ")
    omit = omittables
    
    for i in range(n-1,-1,-1):
        if output_state[i]==0:
            B=np.delete(B,V-(n-i),0)
            B=np.delete(B,V-(n-i),1)
    for i in range(0,n):
        if input_state[i]==0:
            B=np.delete(B,n-i-1,0)
            B=np.delete(B,n-i-1,1)
            omit=omit-1
    PfS= compute_pfaffian_sum(B,omit)
    f.write(str(abs(PfS)**2))
    print "The probability to obtain ", str(output_state), " from ", str(input_state), " is ", str(abs(PfS)**2)
    f.write(". \\\\ \n")


if __name__ == "__main__":
    inputfilepath = raw_input("Specify file: ")
    print "Looking through ", inputfilepath
    inputfile = open(str(inputfilepath))
    
    f=open('output.tex','w')
    n = int(inputfile.readline())
    O = int(inputfile.readline())
    Two = int(inputfile.readline())
    number_of_vertices = n + O*(2*n+4) + Two*(2*n+6) - n
    V = number_of_vertices
    k = 0 #last vertex counter
    q = np.zeros(n) #last vertex on line i
    p = np.zeros(n) #last-last vertex on line i
    T = np.zeros(0) #omittable nodes
    A = np.zeros((V,V),'complex') #Graph matrix
    #g = 0 #gate 
    X = 0 #store latest X-position
    Y = 0 #store latest Y-position
    dist = 1./n #shift between parallel vertices in slice
    
    #f=open('output.tex','w')
    f.write("\\documentclass[a4paper,12pt,landscape]{article} \n  \usepackage{array} \n \usepackage{braket} \n \\usepackage[pass]{geometry} \n \usepackage[landscape]{geometry} \n \\usepackage{amsmath} \n \\pagestyle{empty}  \\usepackage[all]{xy} \n \\input{Qcircuit} \n \\begin{document} \n")
    f.write("\\begin{align*} \n")
    f.write("\\xygraph{")
    f.write("!{<0cm,0cm>;<")
    f.write(str(4./(O+two)))
    f.write("cm,0cm>:<0cm,")
    f.write(str(6./n))
    f.write("cm>::} \n")
    
    for i in range(n-1,-1,-1):
        q[i] = n-1-i
        add_vertex(dist*(n-1-i),n-1-i,n-i-1 )    
    #f.write("!{(")
    #f.write(str(0.5*(n-1-i)))
    #f.write(",")
    #f.write(str(n-1-i))
    #f.write(") }*+{\\bullet_{"+ str(n-i-1)+ "}}=\"" + str(n-i-1) +"\"\n")
    k = n-1
    X = dist*(n-1)
    Y = n-1
    
    for i in range(O+Two):
        final_gate=0
        if i==O+Two-1:
            final_gate=1
        #rubbish=inputfile.read(1)
        which_gate=int(inputfile.readline())
        if which_gate==1:
            qubit_line=int(inputfile.readline())
            U_11 = complex(float(inputfile.readline()),float(inputfile.readline()))
            U_12 = complex(float(inputfile.readline()),float(inputfile.readline()))
            U_21 = complex(float(inputfile.readline()),float(inputfile.readline()))
            U_22 = complex(float(inputfile.readline()),float(inputfile.readline()))
            add_one_qubit_gate(qubit_line,U_11,U_12,U_21,U_22,final_gate)
        elif which_gate==2:
            qubit_line=int(inputfile.readline())
            U1_11 = complex(float(inputfile.readline()),float(inputfile.readline()))
            U1_12 = complex(float(inputfile.readline()),float(inputfile.readline()))
            U1_21 = complex(float(inputfile.readline()),float(inputfile.readline()))
            U1_22 = complex(float(inputfile.readline()),float(inputfile.readline()))
            U2_11 = complex(float(inputfile.readline()),float(inputfile.readline()))
            U2_12 = complex(float(inputfile.readline()),float(inputfile.readline()))
            U2_21 = complex(float(inputfile.readline()),float(inputfile.readline()))
            U2_22 = complex(float(inputfile.readline()),float(inputfile.readline()))
            add_two_qubit_gate(qubit_line,U1_11,U1_12,U1_21,U1_22,U2_11,U2_12,U2_21,U2_22,final_gate)

    #antisymmetrize
    for i in range(V):
        for j in range(V):
            if j>i:
                A[j,i] = - A[i,j]

    #print A
    f.write("} \n \\end{align*} \n")
    f.write("\\newpage \n")
    f.write("The graph matrix is:i \n")
    f.write("\\begin{align*} \n")
    f.write("\\left( \n")
    f.write( "\\setlength{\extrarowheight}{-6} \n")
    f.write("\\begin{array}")
    f.write("{")
    for i in range(V+1):
        f.write("c")
    f.write("} \n")
    for i in range(V):
        f.write("& ")
        f.write("\\mathbf{")
        f.write(str(i))
        f.write("}")
    f.write("\\\\")
    for i in range(V):
        f.write("\mathbf{")
        f.write(str(i))
        f.write("} & ")
        for j in range(V):
            if A[i,j] != 0:
                f.write(str(A[i,j]))
                f.write(" & ")
            else:
                f.write("0")
                f.write(" & ")
        f.write(" \\\\")
    f.write("\\end{array} \\right) \n")
    f.write("\\end{align*} \n")

    print "Specity ", str(n),"-qubit input and output"
    inputstate_raw = raw_input("input state (seperate qubits by comma(,)) ?")
    outputstate_raw = raw_input("output state (seperate qubits by comma(,))?")
    output(A,map(int,inputstate_raw.split(',')),map(int,outputstate_raw.split(',')),T)
    print "Please see output.tex for the results."

    f.write("\\end{document}")
    f.close()