#! /usr/bin/env python
# -*- coding: utf-8 -*-
"""
Created on Fri Mar 28 18:17:55 2014
@author: henrikdreyer
"""
if __name__ == "__main__":
    f=open('circuit','w')
    number_of_qudits = raw_input("Number of qudits? ")
    f.write(number_of_qudits)
    f.write("\n")
    number_of_one_qubit_gates = raw_input("Number of 1-qubit gates? ")
    f.write(number_of_one_qubit_gates) 
    f.write("\n")    
    number_of_two_qubit_gates = raw_input("Number of 2-qubit gates? ")
    f.write(number_of_two_qubit_gates)
    f.write("\n")    
    for i in range(int(number_of_one_qubit_gates)+int(number_of_two_qubit_gates)):        
        one_or_two = raw_input("1 or 2-qubit gate (type 1 or 2)? ")
        f.write(one_or_two)
        f.write("\n")
        acts_on = raw_input("First qubit line it acts on (fist one is 0) ")
        f.write(acts_on)
        f.write("\n")
        if one_or_two == "1":
            f.write(raw_input("Real part of U11? "))
            f.write("\n")
            f.write(raw_input("Imaginary part of U11? "))
            f.write("\n")
            
            f.write(raw_input("Real part of U12? "))
            f.write("\n")
            f.write(raw_input("Imaginary part of U12? "))
            f.write("\n")
            
            f.write(raw_input("Real part of U21? "))
            f.write("\n")
            f.write(raw_input("Imaginary part of U21? "))
            f.write("\n")
            
            f.write(raw_input("Real part of U22? "))
            f.write("\n")
            f.write(raw_input("Imaginary part of U22? "))
            f.write("\n")
        
        elif one_or_two == "2":
            f.write(raw_input("Real part of U1_11? "))
            f.write("\n")
            f.write(raw_input("Imaginary part of U1_11? "))
            f.write("\n")
            
            f.write(raw_input("Real part of U1_12? "))
            f.write("\n")
            f.write(raw_input("Imaginary part of U1_12? "))
            f.write("\n")
            
            f.write(raw_input("Real part of U1_21? "))
            f.write("\n")
            f.write(raw_input("Imaginary part of U1_21? "))
            f.write("\n")
            
            f.write(raw_input("Real part of U1_22? "))
            f.write("\n")
            f.write(raw_input("Imaginary part of U1_22? "))
            f.write("\n")
            
            f.write(raw_input("Real part of U2_11? "))
            f.write("\n")
            f.write(raw_input("Imaginary part of U2_11? "))
            f.write("\n")
            
            f.write(raw_input("Real part of U2_12? "))
            f.write("\n")
            f.write(raw_input("Imaginary part of U2_12? "))
            f.write("\n")
            
            f.write(raw_input("Real part of U2_21? "))
            f.write("\n")
            f.write(raw_input("Imaginary part of U2_21? "))
            f.write("\n")
            
            f.write(raw_input("Real part of U2_22? "))
            f.write("\n")
            f.write(raw_input("Imaginary part of U2_22? "))
            f.write("\n")
           
    print "Done. Output written in  \"circuit\"."